clear all;
taskid = load('./taskid.txt');
retrvdat(taskid);
exit;
