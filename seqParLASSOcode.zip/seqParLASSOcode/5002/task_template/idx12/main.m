clear all;

mkidx12dat();
calcidx12();
