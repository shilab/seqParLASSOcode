function y = fg_func(X)
    y = f_func(X) + g_func(X);
end
